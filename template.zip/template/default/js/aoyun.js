$(document).ready(function(){
	//初始化动画
	if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
	    new WOW().init();
	};
	
	//在线客服
	$('.scroll-top').click(function(){$('html,body').animate({scrollTop: '0px'}, 800);});
	
	$('.online dl').on("mouseover",function(){
		$(this).find("dt").show();
		$(this).siblings().find("dt").hide();
	});
	
	$('.online dl').find('.remove').on("click",function(){
		$(this).parents("dt").hide();
	});
	
	$(window).scroll(function() {
		 if ($(document).scrollTop()<=100){
			 $('.online .scroll-top').hide();
		 }else{
			 $('.online .scroll-top').show();
		 }
		 
	});

});

document.addEventListener('DOMContentLoaded', function () {
    const stickyWrapper = document.getElementById('sticky-nav-wrapper');
    const navIsland = document.getElementById('nav-island');
    const navStuck = document.getElementById('nav-stuck');

    if (stickyWrapper && navIsland && navStuck) {
        window.addEventListener('scroll', () => {
            const wrapperTop = stickyWrapper.getBoundingClientRect().top;
            
            if (wrapperTop <= 60) {
                navIsland.classList.add('opacity-0', 'pointer-events-none', 'scale-95');
                navStuck.classList.remove('opacity-0', 'pointer-events-none', '-translate-y-full');
                navStuck.classList.add('opacity-100', 'translate-y-0');
            } else {
                navIsland.classList.remove('opacity-0', 'pointer-events-none', 'scale-95');
                navStuck.classList.add('opacity-0', 'pointer-events-none', '-translate-y-full');
                navStuck.classList.remove('opacity-100', 'translate-y-0');
            }
        });
    }
    
    const counters = document.querySelectorAll('.counter-number');
    const observerOptions = { threshold: 0.5 };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'none';
                entry.target.offsetHeight;
                entry.target.style.animation = null;
            }
        });
    }, observerOptions);
    
    counters.forEach(counter => observer.observe(counter));
});